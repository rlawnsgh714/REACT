import React from "react";

const Main = () => {
  return (
    <div className="problem">
      <h1>과제의 메인 페이지입니다</h1>
      <p>해당 과제의 번호를 누르면 각 과제 페이지로 이동합니다</p>
    </div>
  );
};

export default Main;
